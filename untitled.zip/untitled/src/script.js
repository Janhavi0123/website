// Function to open the soap modal
function openSoapModal() {
    document.getElementById('soap-modal').style.display = "block";
}

// Function to open the facewash modal
function openFaceWashModal() {
    document.getElementById('facewash-modal').style.display = "block";
}

// Function to open the oil modal
function openOilModal() {
    document.getElementById('oil-modal').style.display = "block";
}

// Function to close the modal
function closeModal(product) {
    document.getElementById(product + '-modal').style.display = "none";
}
